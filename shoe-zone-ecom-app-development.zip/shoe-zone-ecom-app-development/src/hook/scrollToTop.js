export const ScrollToTop = () => {
  return window.scrollTo(0, 0);
};
