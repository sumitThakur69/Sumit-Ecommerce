import "./loader.css";
export const Loader = () => {
  return (
    <div className="loadingio-spinner-dual-ring-uiwbi1kqzx">
      <div className="ldio-6cgnwlzo3z7">
        <div></div>
        <div>
          <div></div>
        </div>
      </div>
    </div>
  );
};
