import mainImg from "./nike-air-force.jpg";
import giftImgOne from "./gift-img-one.jpg";
import giftImgTwo from "./gift-img-two.jpg";
import empty_img from "./empty-meme.jpg";
export { mainImg, giftImgOne, giftImgTwo, empty_img };
