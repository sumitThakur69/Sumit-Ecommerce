import nike_air_max_270 from "./nike-air-max-270.webp";
import nike_air_zoom_AIR from "./air-zoom-pegasus-38-air-jordan-moss-mens-road-running-shoes-lq7PZZ.jpg";
import nike_air_max_90 from "./Nike Air Max 90.webp";
import nike_blazer_mid_77 from "./nike blazer mid77.webp";
import Nike_air_force_107 from "./nike air force 107.webp";
import nike_react_miler from "./nike react miler 2 shield.webp";
import nike_bassi_jdi from "./nike benasi jdi.webp";
import nike_air_max_terrace_cape90 from "./nike air max terrascape 90.webp";
import nike_blazer_next_nature from "./nike blazer low platform next nature.webp";
import nike_pegasus_trail_3 from "./nike pegasus trail 3.webp";
import Nike_air_force_1_fantanka from "./nike force 1 fontanka.webp";
import nike_air_huarache from "./nike air huarache.webp";
import nike_court_legacy from "./nike court legacy.webp";
import nike_air_max_90_ltr from "./nike air max 90 ltr se.webp";
import nike_point_lane from "./jorden-point-lane.webp";
import nike_air_max_2021 from "./nike-air-max-2021.webp";
import nike_sunday_protect from "./nike sunary protect 3.webp";
import nike_revolution_6_se from "./nike revolution 6 se.webp";
export {
  nike_air_max_270,
  nike_air_zoom_AIR,
  nike_air_max_90,
  nike_blazer_mid_77,
  Nike_air_force_107,
  nike_react_miler,
  nike_bassi_jdi,
  nike_air_max_terrace_cape90,
  nike_blazer_next_nature,
  nike_pegasus_trail_3,
  Nike_air_force_1_fantanka,
  nike_air_huarache,
  nike_court_legacy,
  nike_air_max_90_ltr,
  nike_point_lane,
  nike_air_max_2021,
  nike_sunday_protect,
  nike_revolution_6_se,
};
